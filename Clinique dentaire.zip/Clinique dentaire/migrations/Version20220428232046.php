<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20220428232046 extends AbstractMigration
{
    public function getDescription(): string
    {
        return '';
    }

    public function up(Schema $schema): void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('ALTER TABLE dossier DROP CONSTRAINT fk_3d48e0376b899279');
        $this->addSql('DROP INDEX uniq_3d48e0376b899279');
        $this->addSql('ALTER TABLE dossier DROP patient_id');
        $this->addSql('ALTER TABLE patient ADD dossier_id INT NOT NULL');
        $this->addSql('ALTER TABLE patient ADD CONSTRAINT FK_1ADAD7EB611C0C56 FOREIGN KEY (dossier_id) REFERENCES dossier (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_1ADAD7EB611C0C56 ON patient (dossier_id)');
    }

    public function down(Schema $schema): void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE SCHEMA public');
        $this->addSql('ALTER TABLE patient DROP CONSTRAINT FK_1ADAD7EB611C0C56');
        $this->addSql('DROP INDEX UNIQ_1ADAD7EB611C0C56');
        $this->addSql('ALTER TABLE patient DROP dossier_id');
        $this->addSql('ALTER TABLE dossier ADD patient_id INT NOT NULL');
        $this->addSql('ALTER TABLE dossier ADD CONSTRAINT fk_3d48e0376b899279 FOREIGN KEY (patient_id) REFERENCES patient (id) NOT DEFERRABLE INITIALLY IMMEDIATE');
        $this->addSql('CREATE UNIQUE INDEX uniq_3d48e0376b899279 ON dossier (patient_id)');
    }
}
