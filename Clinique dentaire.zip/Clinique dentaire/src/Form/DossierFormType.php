<?php

namespace App\Form;

use App\Entity\Dossier;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;
use Symfony\Component\Form\Extension\Core\Type\TextType;


class DossierFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('antecedent_medicaux',TextType::class,[
                'attr' => [
                'form-control'
                ],
                'label' => 'Antecedent medicaux'
            ])
            ->add('prochain_rendez_vous',TextType::class,[
                'attr' => [
                'form-control'
                ],
                'label' => 'Prochain rendez-vous'
            ])
            ->add('horraire_avec_dentist',TextType::class,[
                'attr' => [
                'form-control'
                ],
                'label' => 'Horraires avec le dentiste'
            ])
            ->add('employe')
            ->add('traitement')
            ->add('patient')
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Dossier::class,
        ]);
    }
}
