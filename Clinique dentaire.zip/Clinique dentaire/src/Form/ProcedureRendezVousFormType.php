<?php

namespace App\Form;

use App\Entity\ProcedureRendezVous;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\DateType;
use Symfony\Component\Form\Extension\Core\Type\NumberType;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class ProcedureRendezVousFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('code_procedure' , IntegerType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'code de procedure'
            ])
            ->add('date', DateType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'Date'
            ])
            ->add('type_procedure', TextType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'Type de procedure'
            ])
            ->add('description', TextType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'Description'
            ])
            ->add('nombre_procedures', IntegerType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'nombre de procedure'
            ])
            ->add('charge_patient', NumberType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'les charge du patient '
            ])
            ->add('charge_assurance', NumberType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'les charges de l\'assurance '
            ])
            ->add('charge_totaux', NumberType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'le totale des charges'
            ])
            ->add('facturationPaiements')
        ;
    }

    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => ProcedureRendezVous::class,
        ]);
    }
}
