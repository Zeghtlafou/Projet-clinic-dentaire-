<?php

namespace App\Form;

use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\CheckboxType;
use Symfony\Component\Form\Extension\Core\Type\DateTimeType;
use Symfony\Component\Form\Extension\Core\Type\BirthdayType;
use Symfony\Component\Form\Extension\Core\Type\DateIntervalType;
use Symfony\Bridge\Doctrine\Form\Type\EntityType;
use Symfony\Component\Form\Extension\Core\Type\TimeType;
use Symfony\Component\Validator\Constraints\IsTrue;
use App\Entity\Patient;
use App\Entity\Dossier;
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\OptionsResolver\OptionsResolver;

class PatientFormType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options): void
    {
        $builder
            ->add('nom', TextType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'Nom'
            ])
            ->add('prenom', TextType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'Prenom'
            ])
            ->add('date_naissance', TextType::class,[
                                
                'attr' => [    
                    'class' => 'form-control'
                ],
                'label' => 'Date de naissance '
            ])
            
            

            ->add('age', IntegerType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'age'
            ])
            ->add('email', TextType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'email'
            ])
            ->add('telephone', TextType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'telephone'
            ])
            ->add('rue', TextType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'rue'
            ])
            ->add('ville', TextType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'ville'
            ])
            ->add('province', TextType::class,[
                'attr' => [
                    'class' => 'form-control'
                ],
                'label' => 'province'
            ])
            ->add('is_assurance')
            ->add('responsable')
            ->add('reclamationAssurance' )
            ->add('traitements')
            ->add('procedureRendezVous')
            ->add('users')
            ->add('dossier'/* , EntityType::class, [
                'class' => Dossier::class,
                'by_reference' => false,
                
                'label' => 'Dossier'
            ]*/)

            //->add('dossier')
        ;
    }
    
    public function configureOptions(OptionsResolver $resolver): void
    {
        $resolver->setDefaults([
            'data_class' => Patient::class,
            'method' => 'GET',
            'csrf_protection' => false
        ]);
    }

    public function getBlockPrefix()
    {
        return '';
    }

    
}
