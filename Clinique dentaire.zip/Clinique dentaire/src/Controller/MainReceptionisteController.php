<?php

namespace App\Controller;

use App\Entity\Succursale;
use App\Entity\Users;
use App\Entity\Patient;
use App\Repository\SuccursaleRepository;
use App\Repository\UsersRepository;
use App\Repository\PatientRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


class MainReceptionisteController extends AbstractController
{
    #[Route('/recption', name: 'mon_receptioniste')]
    public function index(SuccursaleRepository $succursaleRepository,UsersRepository $usersRepository ,PatientRepository $patientRepository ): Response
    {
        
        return $this->render('receptionist_main/index.html.twig', [
            
            'succursale' => $succursaleRepository->findby([],['id' => 'asc']),
            'user' => $usersRepository->findby([],['id' => 'asc']),
            'patient' => $patientRepository->findby([],['id' => 'asc']),

        ]);

        
    }

    /*#[Route('/{info}', name: 'details')]
    public function details(Dossier $dossier): Response
    {
        dd($dossier);
        return $this->render('dossier/details.html.twig',compact('dossier'));
    }*/



}