<?php

namespace App\Controller;

use App\Entity\ProcedureRendezVous;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/procedureRendezVous', name: 'procedure_')]
class ProcedureRendezVousController extends AbstractController
{
    #[Route('/{type_procedure}', name: 'list')]
    public function list(ProcedureRendezVous $procedure): Response
    {
        //on va checher le type de procedure 
        $rdv_type = $procedure->getTypeProcedure();

        return $this->render('procedure_rendez_vous/list.html.twig',compact('procedure','rdv_type'));
    }

    /*#[Route('/{info}', name: 'details')]
    public function details(ProcedureRendezVous $procedure_rdv): Response
    {
        //dd($procedure_rdv);
        return $this->render('procedure_rendez_vous/details.html.twig',compact('procedure_rdv'));
    }*/
}
