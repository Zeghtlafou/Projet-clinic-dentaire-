<?php
namespace App\Controller\Admin;

use App\Entity\Patient;
use App\Form\PatientFormType;
use App\Repository\PatientRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AdminPatientController extends AbstractController
{
    /**
     * @var PatientRepository
     */
    private $repository;
    /**
     * @var EntityManagerInterface
     */
    private $em;

    public function __construct(PatientRepository $repository, EntityManagerInterface $em)
    {
        $this->repository = $repository;
        $this->em = $em;
    }

    
    #[Route('/admin/patients', name: 'admin.patient.index')]
    public function index(): Response
    {
        $patients = $this->repository->findAll();
        return $this->render('admin/patient/index.html.twig', compact('patients'));
    }

    
    #[Route('/admin/patient/ajouter', name: 'admin.patient.new')]
    public function new(Request $request): Response
    
    {
        $patient = new Patient();
        $form = $this->createForm(PatientFormType::class, $patient);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $this->em->persist($patient);
            $this->em->flush();
            $this->addFlash('success', 'Patient cr�� avec succ�s');
            return $this->redirectToRoute('admin.patient.index');
        }

        return $this->render('admin/patient/new.html.twig', [
            'patient' => $patient,
            'form' => $form->createView()
        ]);
    }

    
    #[Route('/admin/patient/{id}', name: 'admin.patient.edit', methods:['GET','POST'])]
    public function edit(Patient $patient, Request $request): Response
    {
        $form = $this->createForm(PatientFormType::class, $patient);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $this->em->flush();
            $this->addFlash('success', 'Patient modifi� avec succ�s');
            return $this->redirectToRoute('admin.patient.index');
        }

        return $this->render('admin/patient/edit.html.twig', [
            'patient' => $patient,
            'form' => $form->createView()
        ]);
    }

     
    #[Route('/admin/patient/{id}', name: 'admin.patient.delete', methods:['DELETE'])]
    public function delete(Patient $patient, Request $request)
    {
        if ($this->isCsrfTokenValid('delete' . $patient->getId(), $request->get('_token')))
        {
            $this->em->remove($patient);
            $this->addFlash('success', 'Patient supprim�');
            $this->em->flush();
        }

        return $this->redirectToRoute('admin.patient.index');
    }

}