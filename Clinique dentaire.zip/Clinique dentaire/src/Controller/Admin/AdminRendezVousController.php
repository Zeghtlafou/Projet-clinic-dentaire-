<?php
namespace App\Controller\Admin;

use App\Entity\RendezVous;
use App\Form\RendezVousFormType;
use App\Repository\RendezVousRepository;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class AdminRendezVousController extends AbstractController
{
    /**
     * @var PatientRepository
     */
    private $repository;
    /**
     * @var EntityManagerInterface
     */
    private $em;

    public function __construct(RendezVousRepository $repository, EntityManagerInterface $em)
    {
        $this->repository = $repository;
        $this->em = $em;
    }

    
    #[Route('/admin/rendezvous_', name: 'admin.rendezvous.index')]
    public function index(): Response
    {
        $rdvs = $this->repository->findAll();
        return $this->render('admin/rendezvous/index.html.twig', compact('rdvs'));
    }

    
    #[Route('/admin/rendezvous/ajouter', name: 'admin.rendezvous.new')]
    public function new(Request $request): Response
    
    {
        $rdv = new RendezVous();
        $form = $this->createForm(RendezVousFormType::class, $rdv);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $this->em->persist($rdv);
            $this->em->flush();
            $this->addFlash('success', 'Rendez-vous ajouter avec succes');
            return $this->redirectToRoute('admin.rendezvous.index');
        }

        return $this->render('admin/rendezvous/new.html.twig', [
            'rdv' => $rdv,
            'form' => $form->createView()
        ]);
    }

     

     
   

    
    

}