<?php

namespace App\Controller;

use App\Entity\RendezVous;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\ParamConverter;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/rendez/vous', name: 'rendez_vous_')]
class RendezVousController extends AbstractController
{
    
    #[Route('/{jour}', name: 'list')]
    /*#[ParamConverter(
        'rdv',
        class: RendezVous::class,
        options: ['id' => 'jour'],
    )]*/
    public function list(RendezVous $rdv): Response
    {
        //on va chercher la date du rendez-vous pour verifier le rendez-vous 
        //$verification = $rdv->getJour();
        //$heure = $rdv->getHeureDebut();

        //dd($rdv->getJour());
        //dd($rdv->getHeureDebut());
        
        return $this->render('rendez_vous/list.html.twig',compact('rdv')/*,'verification','heure'*/);
    }

    /*#[Route('/{jour}', name: 'details')]
    public function details(RendezVous $rdv): Response
    {
        //dd($rdv)
        return $this->render('rendez_vous/details.html.twig',compact('rdv'));
    }*/
}
