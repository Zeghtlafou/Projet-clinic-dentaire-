<?php

namespace App\Controller;

use App\Entity\Succursale;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/dentist', name: 'dentiste_')]
class DentistController extends AbstractController
{
    #[Route('/{dentiste}', name: 'list')]
    public function list(Succursale $succursale): Response
    {
        // on va chercher le dentiste dans chaque Succursale
        $nom =$succursale->getDentiste();

        return $this->render('dentist/list.html.twig',compact('succursale','nom'));
    }
}
