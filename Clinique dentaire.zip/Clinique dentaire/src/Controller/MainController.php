<?php

namespace App\Controller;

use App\Repository\SuccursaleRepository;
use App\Repository\RendezVousRepository;
use App\Repository\ProcedureRendezVousRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class MainController extends AbstractController
{
    #[Route('/', name: 'main')]
    public function index(SuccursaleRepository $succursaleRepository,ProcedureRendezVousRepository $procedureRendezVousRepository,RendezVousRepository $prochain_rdvRepository): Response
    {
        return $this->render('main/index.html.twig',[
            'succursale' => $succursaleRepository->findby([],['id' => 'asc']),
            'procedure_rdv' => $procedureRendezVousRepository->findby([],['id' => 'asc']),
            'prochain_rdv' => $prochain_rdvRepository->findby([],['id' => 'asc'])
        ]);
    }
    
    /*#[Route('/rdv', name: 'details')]
    public function details(RendezVousRepository $rendezVousRepository ): Response
    {
        return $this->render('main/index.html.twig',[
            'rendez_vous' => $rendezVousRepository->findby([],['id' => 'asc'])
        ]);
    }*/

}
