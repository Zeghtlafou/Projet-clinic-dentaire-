<?php

namespace App\Controller;

use App\Entity\Patient;
use App\Entity\ProcedureRendezVous;
use App\Entity\PatientSearch;
use App\Form\PatientSearchType;
use App\Repository\PatientRepository;
use App\Form\ProcedureRendezVousFormType;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Form\Extension\Core\Type\IntegerType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

class PatientController extends AbstractController
{
    /**
     * @var PatientRepository
     */
    private $repository;
    /**
     * @var EntityManagerInterface
     */
    private $em;


    public function __construct(PatientRepository $repository, EntityManagerInterface $em)
    {
        $this->repository = $repository;
        $this->em = $em;
    }

    #[Route('/patients', name: 'app_patient')]
    public function index(Request $request): Response
    {
        $search = new PatientSearch();
        $form = $this->createForm(PatientSearchType::class , $search);
        $form->handleRequest($request);

        if($search->name){
            $patients = $this->repository->findByName($search->name);
        
        }
        else{
             $patients = $this->repository->findAll();
        }

        return $this->render('patient/index.html.twig', [
            'patients'=> $patients,
            'form'=> $form->createView()

        ]);
    }

    #[Route('/procedure/ajouter', name: 'procedur.new')]
    public function new(Request $request): Response
    
    {
        $procedure = new ProcedureRendezVous();
        $form = $this->createForm(ProcedureRendezVousFormType::class, $procedure);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid())
        {
            $this->em->persist($procedure);
            $this->em->flush();
            $this->addFlash('success', 'Procedure cree avec succes');
            return $this->redirectToRoute('app_patient');
        }

        return $this->render('patient/new.html.twig', [
            'procedure' => $procedure,
            'form' => $form->createView()
        ]);
    }
}
