<?php

namespace App\Controller;

use App\Entity\Dossier;
use App\Entity\Users;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/dossier', name: 'dossier_')]
class DossierController extends AbstractController
{
    
    #[Route('/{antecedent_medicaux}/{prochain_rendez_vous}/{horraire_avec_dentist}', name: 'info'  )]
    public function list(Dossier $my_doc): Response
    {
        return $this->render('dossier/list.html.twig',compact('my_doc'));
    }
  
}
