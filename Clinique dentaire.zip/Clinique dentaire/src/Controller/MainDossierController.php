<?php

namespace App\Controller;

use App\Entity\Dossier;
use App\Entity\Users;
use App\Repository\DossierRepository;
use App\Repository\UsersRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;


class MainDossierController extends AbstractController
{
    #[Route('/dossier', name: 'dossier')]
    public function index(DossierRepository $dossierRepository,UsersRepository $userRepository): Response
    {
        
        return $this->render('dossier_main/index.html.twig', [
            //'controller_name' => 'DossierController',
            'dossier' => $dossierRepository->findby([],['id' => 'asc']),
            'user' => $userRepository->findby([],['id' => 'asc']),

        ]);

        
    }

    /*#[Route('/{info}', name: 'details')]
    public function details(Dossier $dossier): Response
    {
        dd($dossier);
        return $this->render('dossier/details.html.twig',compact('dossier'));
    }*/



}
