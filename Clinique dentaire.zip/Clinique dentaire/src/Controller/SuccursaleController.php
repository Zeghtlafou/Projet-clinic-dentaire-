<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

#[Route('/succursale', name: 'succursale_')]
class SuccursaleController extends AbstractController
{
    #[Route('/{dentiste}', name: 'index')]
    public function index(): Response
    {
        //on va chercher la liste de dentiste dans chaque succursale
        //$dentiste = $succursale->getDentiste();

        return $this->render('succursale/index.html.twig');
    }
    #[Route('/{dentiste}', name: 'details')]
    public function details(Succursale $succursale): Response
    {
        dd($succursale);
        return $this->render('succursale/details.html.twig', compact('succursale'));
    }
}
