<?php

namespace App\Entity;

use App\Repository\EmployeRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: EmployeRepository::class)]
class Employe
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 100)]
    private $nom;

    #[ORM\Column(type: 'string', length: 100)]
    private $prenom;

    #[ORM\Column(type: 'string', length: 255)]
    private $adresse;

    #[ORM\Column(type: 'string', length: 100)]
    private $role;

    #[ORM\Column(type: 'float')]
    private $salaire;

    #[ORM\Column(type: 'string', length: 255)]
    private $honoraire;

    #[ORM\OneToOne(inversedBy: 'employe', targetEntity: Traitement::class, cascade: ['persist', 'remove'])]
    #[ORM\JoinColumn(nullable: false)]
    private $traitement;

    #[ORM\ManyToOne(targetEntity: Succursale::class, inversedBy: 'employe')]
    #[ORM\JoinColumn(nullable: false)]
    private $succursale;

    #[ORM\OneToMany(mappedBy: 'employe', targetEntity: Dossier::class)]
    private $dossiers;

    //#[ORM\OneToMany(mappedBy: 'employe', targetEntity: FacturationPaiement::class)]
    //private $facturationPaiements;

    #[ORM\OneToOne(inversedBy: 'employe', targetEntity: Users::class, cascade: ['persist', 'remove'])]
    #[ORM\JoinColumn(nullable: false)]
    private $users;

    #[ORM\ManyToOne(targetEntity: FacturationPaiement::class, inversedBy: 'employe')]
    private $facturationPaiement;

    public function __construct()
    {
        $this->dossiers = new ArrayCollection();
        $this->facturationPaiements = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    public function getAdresse(): ?string
    {
        return $this->adresse;
    }

    public function setAdresse(string $adresse): self
    {
        $this->adresse = $adresse;

        return $this;
    }

    public function getRole(): ?string
    {
        return $this->role;
    }

    public function setRole(string $role): self
    {
        $this->role = $role;

        return $this;
    }

    public function getSalaire(): ?float
    {
        return $this->salaire;
    }

    public function setSalaire(float $salaire): self
    {
        $this->salaire = $salaire;

        return $this;
    }

    public function getHonoraire(): ?string
    {
        return $this->honoraire;
    }

    public function setHonoraire(string $honoraire): self
    {
        $this->honoraire = $honoraire;

        return $this;
    }

    public function getTraitement(): ?Traitement
    {
        return $this->traitement;
    }

    public function setTraitement(Traitement $traitement): self
    {
        $this->traitement = $traitement;

        return $this;
    }

    public function getSuccursale(): ?Succursale
    {
        return $this->succursale;
    }

    public function setSuccursale(?Succursale $succursale): self
    {
        $this->succursale = $succursale;

        return $this;
    }

    /**
     * @return Collection<int, Dossier>
     */
    public function getDossiers(): Collection
    {
        return $this->dossiers;
    }

    public function addDossier(Dossier $dossier): self
    {
        if (!$this->dossiers->contains($dossier)) {
            $this->dossiers[] = $dossier;
            $dossier->setEmploye($this);
        }

        return $this;
    }

    public function removeDossier(Dossier $dossier): self
    {
        if ($this->dossiers->removeElement($dossier)) {
            // set the owning side to null (unless already changed)
            if ($dossier->getEmploye() === $this) {
                $dossier->setEmploye(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, FacturationPaiement>
     */
   /* public function getFacturationPaiements(): Collection
    {
        return $this->facturationPaiements;
    }

    public function addFacturationPaiement(FacturationPaiement $facturationPaiement): self
    {
        if (!$this->facturationPaiements->contains($facturationPaiement)) {
            $this->facturationPaiements[] = $facturationPaiement;
            $facturationPaiement->setEmploye($this);
        }

        return $this;
    }

    public function removeFacturationPaiement(FacturationPaiement $facturationPaiement): self
    {
        if ($this->facturationPaiements->removeElement($facturationPaiement)) {
            // set the owning side to null (unless already changed)
            if ($facturationPaiement->getEmploye() === $this) {
                $facturationPaiement->setEmploye(null);
            }
        }

        return $this;
    }*/

    public function getUsers(): ?Users
    {
        return $this->users;
    }

    public function setUsers(Users $users): self
    {
        $this->users = $users;

        return $this;
    }

    public function getFacturationPaiement(): ?FacturationPaiement
    {
        return $this->facturationPaiement;
    }

    public function setFacturationPaiement(?FacturationPaiement $facturationPaiement): self
    {
        $this->facturationPaiement = $facturationPaiement;

        return $this;
    }
}
