<?php

namespace App\Entity;

use App\Repository\TraitementRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: TraitementRepository::class)]
class Traitement
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 100)]
    private $type;

    #[ORM\Column(type: 'string', length: 100)]
    private $medicament;

    #[ORM\Column(type: 'string', length: 100, nullable: true)]
    private $symptomes;

    #[ORM\Column(type: 'string', length: 255)]
    private $commentaire;

    #[ORM\Column(type: 'float')]
    private $salaire;

    #[ORM\Column(type: 'string', length: 255)]
    private $honoraire;

   

    #[ORM\OneToOne(mappedBy: 'traitement', targetEntity: Employe::class, cascade: ['persist', 'remove'])]
    private $employe;

    #[ORM\OneToOne(mappedBy: 'traitement', targetEntity: Dossier::class, cascade: ['persist', 'remove'])]
    private $dossier;

    #[ORM\ManyToMany(targetEntity: Patient::class, mappedBy: 'traitements')]
    private $patients;

    public function __construct()
    {
        $this->patients = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getType(): ?string
    {
        return $this->type;
    }

    public function setType(string $type): self
    {
        $this->type = $type;

        return $this;
    }

    public function getMedicament(): ?string
    {
        return $this->medicament;
    }

    public function setMedicament(string $medicament): self
    {
        $this->medicament = $medicament;

        return $this;
    }

    public function getSymptomes(): ?string
    {
        return $this->symptomes;
    }

    public function setSymptomes(?string $symptomes): self
    {
        $this->symptomes = $symptomes;

        return $this;
    }

    public function getCommentaire(): ?string
    {
        return $this->commentaire;
    }

    public function setCommentaire(string $commentaire): self
    {
        $this->commentaire = $commentaire;

        return $this;
    }

    public function getSalaire(): ?float
    {
        return $this->salaire;
    }

    public function setSalaire(float $salaire): self
    {
        $this->salaire = $salaire;

        return $this;
    }

    public function getHonoraire(): ?string
    {
        return $this->honoraire;
    }

    public function setHonoraire(string $honoraire): self
    {
        $this->honoraire = $honoraire;

        return $this;
    }

    

    public function getEmploye(): ?Employe
    {
        return $this->employe;
    }

    public function setEmploye(Employe $employe): self
    {
        // set the owning side of the relation if necessary
        if ($employe->getTraitement() !== $this) {
            $employe->setTraitement($this);
        }

        $this->employe = $employe;

        return $this;
    }

    public function getDossier(): ?Dossier
    {
        return $this->dossier;
    }

    public function setDossier(Dossier $dossier): self
    {
        // set the owning side of the relation if necessary
        if ($dossier->getTraitement() !== $this) {
            $dossier->setTraitement($this);
        }

        $this->dossier = $dossier;

        return $this;
    }
    public function __toString(){
    return $this->medicament ; // Remplacer champ par une propri�t� "string" de l'entit�
    }

    /**
     * @return Collection<int, Patient>
     */
    public function getPatients(): Collection
    {
        return $this->patients;
    }

    public function addPatient(Patient $patient): self
    {
        if (!$this->patients->contains($patient)) {
            $this->patients[] = $patient;
            $patient->addTraitement($this);
        }

        return $this;
    }

    public function removePatient(Patient $patient): self
    {
        if ($this->patients->removeElement($patient)) {
            $patient->removeTraitement($this);
        }

        return $this;
    }
}
