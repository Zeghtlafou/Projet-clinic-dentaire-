<?php

namespace App\Entity;

use App\Entity\Dossier;
use App\Repository\PatientRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: PatientRepository::class)]
class Patient
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 100)]
    private $nom;

    #[ORM\Column(type: 'string', length: 100)]
    private $prenom;

    #[ORM\Column(type: 'string', length: 255)]
    private $date_naissance;

    #[ORM\Column(type: 'integer')]
    private $age;

    #[ORM\Column(type: 'string', length: 100)]
    private $email;

    #[ORM\Column(type: 'string', length: 100, nullable: true)]
    private $telephone;

    #[ORM\Column(type: 'string', length: 255)]
    private $rue;

    #[ORM\Column(type: 'string', length: 100)]
    private $ville;

    #[ORM\Column(type: 'string', length: 100)]
    private $province;

    #[ORM\Column(type: 'boolean')]
    private $is_assurance;

    #[ORM\OneToOne(mappedBy: 'patient', targetEntity: Responsable::class, cascade: ['persist', 'remove'])]
    private $responsable;

    #[ORM\OneToOne(mappedBy: 'patient', targetEntity: ReclamationAssurance::class, cascade: ['persist', 'remove'])]
    private $reclamationAssurance;

    

    #[ORM\OneToMany(mappedBy: 'patient', targetEntity: Avis::class)]
    private $avis;

    #[ORM\OneToMany(mappedBy: 'patient', targetEntity: Facture::class)]
    private $factures;

    #[ORM\ManyToOne(targetEntity: ProcedureRendezVous::class, inversedBy: 'patient')]
    #[ORM\JoinColumn(nullable: false)]
    private $procedureRendezVous;

    #[ORM\OneToOne(inversedBy: 'patient', targetEntity: Users::class, cascade: ['persist', 'remove'])]
    #[ORM\JoinColumn(nullable: false)]
    private $users;

    /*#[ORM\OneToOne(inversedBy: 'patient', targetEntity: Dossier::class, cascade: ['persist', 'remove'])]
    #[ORM\JoinColumn(nullable: false)]
    private $dossier;*/

    #[ORM\ManyToMany(targetEntity: Traitement::class, inversedBy: 'patients')]
    private $traitements;

    #[ORM\OneToOne(inversedBy: 'patient', targetEntity: Dossier::class, cascade: ['persist', 'remove'])]
    #[ORM\JoinColumn(nullable: false)]
    private $dossier;

    

    

    

   

    public function __construct()
    {
        $this->avis = new ArrayCollection();
        $this->factures = new ArrayCollection();
        $this->traitements = new ArrayCollection();
        
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getNom(): ?string
    {
        return $this->nom;
    }

    public function setNom(string $nom): self
    {
        $this->nom = $nom;

        return $this;
    }

    public function getPrenom(): ?string
    {
        return $this->prenom;
    }

    public function setPrenom(string $prenom): self
    {
        $this->prenom = $prenom;

        return $this;
    }

    public function getDateNaissance(): ?string
    {
        return $this->date_naissance;
    }

    public function setDateNaissance(string $date_naissance): self
    {
        $this->date_naissance = $date_naissance;

        return $this;
    }

    public function getAge(): ?int
    {
        return $this->age;
    }

    public function setAge(int $age): self
    {
        $this->age = $age;

        return $this;
    }

    public function getEmail(): ?string
    {
        return $this->email;
    }

    public function setEmail(string $email): self
    {
        $this->email = $email;

        return $this;
    }

    public function getTelephone(): ?string
    {
        return $this->telephone;
    }

    public function setTelephone(?string $telephone): self
    {
        $this->telephone = $telephone;

        return $this;
    }

    public function getRue(): ?string
    {
        return $this->rue;
    }

    public function setRue(string $rue): self
    {
        $this->rue = $rue;

        return $this;
    }

    public function getVille(): ?string
    {
        return $this->ville;
    }

    public function setVille(string $ville): self
    {
        $this->ville = $ville;

        return $this;
    }

    public function getProvince(): ?string
    {
        return $this->province;
    }

    public function setProvince(string $province): self
    {
        $this->province = $province;

        return $this;
    }

    public function getIsAssurance(): ?bool
    {
        return $this->is_assurance;
    }

    public function setIsAssurance(bool $is_assurance): self
    {
        $this->is_assurance = $is_assurance;

        return $this;
    }

    public function getResponsable(): ?Responsable
    {
        return $this->responsable;
    }

    public function setResponsable(?Responsable $responsable): self
    {
        // unset the owning side of the relation if necessary
        if ($responsable === null && $this->responsable !== null) {
            $this->responsable->setPatient(null);
        }

        // set the owning side of the relation if necessary
        if ($responsable !== null && $responsable->getPatient() !== $this) {
            $responsable->setPatient($this);
        }

        $this->responsable = $responsable;

        return $this;
    }

    public function getReclamationAssurance(): ?ReclamationAssurance
    {
        return $this->reclamationAssurance;
    }

    public function setReclamationAssurance(?ReclamationAssurance $reclamationAssurance): self
    {
        // unset the owning side of the relation if necessary
        if ($reclamationAssurance === null && $this->reclamationAssurance !== null) {
            $this->reclamationAssurance->setPatient(null);
        }

        // set the owning side of the relation if necessary
        if ($reclamationAssurance !== null && $reclamationAssurance->getPatient() !== $this) {
            $reclamationAssurance->setPatient($this);
        }

        $this->reclamationAssurance = $reclamationAssurance;

        return $this;
    }

    
    /**
     * @return Collection<int, Avis>
     */
    public function getAvis(): Collection
    {
        return $this->avis;
    }

    public function addAvi(Avis $avi): self
    {
        if (!$this->avis->contains($avi)) {
            $this->avis[] = $avi;
            $avi->setPatient($this);
        }

        return $this;
    }

    public function removeAvi(Avis $avi): self
    {
        if ($this->avis->removeElement($avi)) {
            // set the owning side to null (unless already changed)
            if ($avi->getPatient() === $this) {
                $avi->setPatient(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, Facture>
     */
    public function getFactures(): Collection
    {
        return $this->factures;
    }

    public function addFacture(Facture $facture): self
    {
        if (!$this->factures->contains($facture)) {
            $this->factures[] = $facture;
            $facture->setPatient($this);
        }

        return $this;
    }

    public function removeFacture(Facture $facture): self
    {
        if ($this->factures->removeElement($facture)) {
            // set the owning side to null (unless already changed)
            if ($facture->getPatient() === $this) {
                $facture->setPatient(null);
            }
        }

        return $this;
    }

    public function getProcedureRendezVous(): ?ProcedureRendezVous
    {
        return $this->procedureRendezVous;
    }

    public function setProcedureRendezVous(?ProcedureRendezVous $procedureRendezVous): self
    {
        $this->procedureRendezVous = $procedureRendezVous;

        return $this;
    }

    public function getUsers(): ?Users
    {
        return $this->users;
    }

    public function setUsers(Users $users): self
    {
        $this->users = $users;

        return $this;
    }

    /*public function getDossier(): ?Dossier
    {
        return $this->dossier;
    }

    public function setDossier(Dossier $dossier): self
    {
        $this->dossier = $dossier;

        return $this;
    }*/
    public function __toString(){
    return (string)$this->date_naissance ; // Remplacer champ par une propri�t� "string" de l'entit�
    }

    /**
     * @return Collection<int, Traitement>
     */
    public function getTraitements(): Collection
    {
        return $this->traitements;
    }

    public function addTraitement(Traitement $traitement): self
    {
        if (!$this->traitements->contains($traitement)) {
            $this->traitements[] = $traitement;
        }

        return $this;
    }

    public function removeTraitement(Traitement $traitement): self
    {
        $this->traitements->removeElement($traitement);

        return $this;
    }

    public function getDossier(): ?Dossier
    {
        return $this->dossier;
    }

    public function setDossier(Dossier $dossier): self
    {
        $this->dossier = $dossier;

        return $this;
    }

    

    

   

    
}
