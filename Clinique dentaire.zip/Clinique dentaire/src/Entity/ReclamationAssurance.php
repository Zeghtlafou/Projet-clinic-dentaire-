<?php

namespace App\Entity;

use App\Repository\ReclamationAssuranceRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ReclamationAssuranceRepository::class)]
class ReclamationAssurance
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'float')]
    private $frais;

    #[ORM\OneToOne(inversedBy: 'reclamationAssurance', targetEntity: Patient::class, cascade: ['persist', 'remove'])]
    private $patient;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getFrais(): ?float
    {
        return $this->frais;
    }

    public function setFrais(float $frais): self
    {
        $this->frais = $frais;

        return $this;
    }

    public function getPatient(): ?Patient
    {
        return $this->patient;
    }

    public function setPatient(?Patient $patient): self
    {
        $this->patient = $patient;

        return $this;
    }
    public function __toString(){
    return (string)$this->frais ; // Remplacer champ par une propri�t� "string" de l'entit�
    }
}
