<?php

namespace App\Entity;

use App\Repository\DossierRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: DossierRepository::class)]
class Dossier
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\ManyToOne(targetEntity: Employe::class, inversedBy: 'dossiers')]
    #[ORM\JoinColumn(nullable: false)]
    private $employe;

    #[ORM\OneToOne(inversedBy: 'dossier', targetEntity: Traitement::class, cascade: ['persist', 'remove'])]
    #[ORM\JoinColumn(nullable: false)]
    private $traitement;

    /*#[ORM\OneToOne(mappedBy: 'dossier', targetEntity: Patient::class, cascade: ['persist', 'remove'])]
    private $patient;*/

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private $antecedent_medicaux;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private $prochain_rendez_vous;

    #[ORM\Column(type: 'string', length: 255, nullable: true)]
    private $horraire_avec_dentist;

    #[ORM\OneToOne(mappedBy: 'dossier', targetEntity: Patient::class, cascade: ['persist', 'remove'])]
    private $patient;

   

   

    

    

    

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEmploye(): ?Employe
    {
        return $this->employe;
    }

    public function setEmploye(?Employe $employe): self
    {
        $this->employe = $employe;

        return $this;
    }

    public function getTraitement(): ?Traitement
    {
        return $this->traitement;
    }

    public function setTraitement(Traitement $traitement): self
    {
        $this->traitement = $traitement;

        return $this;
    }

    /*public function getPatient(): ?Patient
    {
        return $this->patient;
    }

    public function setPatient(Patient $patient): self
    {
        // set the owning side of the relation if necessary
        if ($patient->getDossier() !== $this) {
            $patient->setDossier($this);
        }

        $this->patient = $patient;

        return $this;
    }*/

    public function getAntecedentMedicaux(): ?string
    {
        return $this->antecedent_medicaux;
    }

    public function setAntecedentMedicaux(?string $antecedent_medicaux): self
    {
        $this->antecedent_medicaux = $antecedent_medicaux;

        return $this;
    }

    public function getProchainRendezVous(): ?string
    {
        return $this->prochain_rendez_vous;
    }

    public function setProchainRendezVous(?string $prochain_rendez_vous): self
    {
        $this->prochain_rendez_vous = $prochain_rendez_vous;

        return $this;
    }

    public function getHorraireAvecDentist(): ?string
    {
        return $this->horraire_avec_dentist;
    }

    public function setHorraireAvecDentist(string $horraire_avec_dentist): self
    {
        $this->horraire_avec_dentist = $horraire_avec_dentist;

        return $this;
    }
    public function __toString(){
    return $this->antecedent_medicaux ; // Remplacer champ par une propri�t� "string" de l'entit�
    }

    public function getPatient(): ?Patient
    {
        return $this->patient;
    }

    public function setPatient(Patient $patient): self
    {
        // set the owning side of the relation if necessary
        if ($patient->getDossier() !== $this) {
            $patient->setDossier($this);
        }

        $this->patient = $patient;

        return $this;
    }

    

    

    

   

    
}
