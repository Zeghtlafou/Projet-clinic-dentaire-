<?php

namespace App\Entity;

use App\Repository\SuccursaleRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: SuccursaleRepository::class)]
class Succursale
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 100)]
    private $ville;

    #[ORM\Column(type: 'string', length: 100)]
    private $directeur;

    #[ORM\Column(type: 'string', length: 100)]
    private $dentiste;

    #[ORM\Column(type: 'string', length: 100)]
    private $hygieniste;

    #[ORM\Column(type: 'string', length: 100)]
    private $receptioniste;

    #[ORM\OneToMany(mappedBy: 'succursale', targetEntity: Employe::class)]
    private $employe;

    public function __construct()
    {
        $this->employe = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getVille(): ?string
    {
        return $this->ville;
    }

    public function setVille(string $ville): self
    {
        $this->ville = $ville;

        return $this;
    }

    public function getDirecteur(): ?string
    {
        return $this->directeur;
    }

    public function setDirecteur(string $directeur): self
    {
        $this->directeur = $directeur;

        return $this;
    }

    public function getDentiste(): ?string
    {
        return $this->dentiste;
    }

    public function setDentiste(string $dentiste): self
    {
        $this->dentiste = $dentiste;

        return $this;
    }

    public function getHygieniste(): ?string
    {
        return $this->hygieniste;
    }

    public function setHygieniste(string $hygieniste): self
    {
        $this->hygieniste = $hygieniste;

        return $this;
    }

    public function getReceptioniste(): ?string
    {
        return $this->receptioniste;
    }

    public function setReceptioniste(string $receptioniste): self
    {
        $this->receptioniste = $receptioniste;

        return $this;
    }

    /**
     * @return Collection<int, Employe>
     */
    public function getEmploye(): Collection
    {
        return $this->employe;
    }

    public function addEmploye(Employe $employe): self
    {
        if (!$this->employe->contains($employe)) {
            $this->employe[] = $employe;
            $employe->setSuccursale($this);
        }

        return $this;
    }

    public function removeEmploye(Employe $employe): self
    {
        if ($this->employe->removeElement($employe)) {
            // set the owning side to null (unless already changed)
            if ($employe->getSuccursale() === $this) {
                $employe->setSuccursale(null);
            }
        }

        return $this;
    }
}
