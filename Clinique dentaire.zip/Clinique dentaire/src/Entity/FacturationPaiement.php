<?php

namespace App\Entity;

use App\Repository\FacturationPaiementRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: FacturationPaiementRepository::class)]
class FacturationPaiement
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'float')]
    private $paiement_patient;

    #[ORM\Column(type: 'float', nullable: true)]
    private $paiement_assurance;

    #[ORM\Column(type: 'float')]
    private $montant_totale;

    #[ORM\Column(type: 'string', length: 100)]
    private $type_paiement;

    #[ORM\OneToMany(mappedBy: 'facturationPaiement', targetEntity: Employe::class)]
    private $employe;

    

    #[ORM\ManyToMany(targetEntity: RendezVous::class, mappedBy: 'facturation_paiement')]
    private $rendezVouses;

    #[ORM\ManyToOne(targetEntity: ProcedureRendezVous::class, inversedBy: 'facturationPaiements')]
    private $procedure;

   

    

    

    public function __construct()
    {
        $this->employe = new ArrayCollection();
        $this->procedureRendezVouses = new ArrayCollection();
        $this->rendezVouses = new ArrayCollection();
        $this->procedurerendezVouses = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getPaiementPatient(): ?float
    {
        return $this->paiement_patient;
    }

    public function setPaiementPatient(float $paiement_patient): self
    {
        $this->paiement_patient = $paiement_patient;

        return $this;
    }

    public function getPaiementAssurance(): ?float
    {
        return $this->paiement_assurance;
    }

    public function setPaiementAssurance(?float $paiement_assurance): self
    {
        $this->paiement_assurance = $paiement_assurance;

        return $this;
    }

    public function getMontantTotale(): ?float
    {
        return $this->montant_totale;
    }

    public function setMontantTotale(float $montant_totale): self
    {
        $this->montant_totale = $montant_totale;

        return $this;
    }

    public function getTypePaiement(): ?string
    {
        return $this->type_paiement;
    }

    public function setTypePaiement(string $type_paiement): self
    {
        $this->type_paiement = $type_paiement;

        return $this;
    }

    /**
     * @return Collection<int, Employe>
     */
    public function getEmploye(): Collection
    {
        return $this->employe;
    }

    public function addEmploye(Employe $employe): self
    {
        if (!$this->employe->contains($employe)) {
            $this->employe[] = $employe;
            $employe->setFacturationPaiement($this);
        }

        return $this;
    }

    public function removeEmploye(Employe $employe): self
    {
        if ($this->employe->removeElement($employe)) {
            // set the owning side to null (unless already changed)
            if ($employe->getFacturationPaiement() === $this) {
                $employe->setFacturationPaiement(null);
            }
        }

        return $this;
    }

    
    
    public function __toString(){
    return $this->type_paiement ; // Remplacer champ par une propri�t� "string" de l'entit�
    }

    /**
     * @return Collection<int, RendezVous>
     */
    public function getRendezVouses(): Collection
    {
        return $this->rendezVouses;
    }

    public function addRendezVouse(RendezVous $rendezVouse): self
    {
        if (!$this->rendezVouses->contains($rendezVouse)) {
            $this->rendezVouses[] = $rendezVouse;
            $rendezVouse->addFacturationPaiement($this);
        }

        return $this;
    }

    public function removeRendezVouse(RendezVous $rendezVouse): self
    {
        if ($this->rendezVouses->removeElement($rendezVouse)) {
            $rendezVouse->removeFacturationPaiement($this);
        }

        return $this;
    }

    public function getProcedure(): ?ProcedureRendezVous
    {
        return $this->procedure;
    }

    public function setProcedure(?ProcedureRendezVous $procedure): self
    {
        $this->procedure = $procedure;

        return $this;
    }

    

    
}
