<?php

namespace App\Entity;

use App\Repository\AjouterRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: AjouterRepository::class)]
class Ajouter
{
   
    #[ORM\Id]
    #[ORM\ManyToOne(targetEntity: Facture::class, inversedBy: 'ajouters')]
    #[ORM\JoinColumn(nullable: false)]
    private $facture;

    #[ORM\Id]
    #[ORM\ManyToOne(targetEntity: RendezVous::class, inversedBy: 'ajouters')]
    #[ORM\JoinColumn(nullable: false)]
    private $rendez_vous;

   

    public function getFacture(): ?Facture
    {
        return $this->facture;
    }

    public function setFacture(?Facture $facture): self
    {
        $this->facture = $facture;

        return $this;
    }

    public function getRendezVous(): ?RendezVous
    {
        return $this->rendez_vous;
    }

    public function setRendezVous(?RendezVous $rendez_vous): self
    {
        $this->rendez_vous = $rendez_vous;

        return $this;
    }
}
