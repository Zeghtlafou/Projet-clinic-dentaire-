<?php

namespace App\Entity;

use App\Repository\ProcedureRendezVousRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: ProcedureRendezVousRepository::class)]
class ProcedureRendezVous
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'integer', unique: true)]
    private $code_procedure;

    #[ORM\Column(type: 'date')]
    private $date;

    #[ORM\Column(type: 'string', length: 100)]
    private $type_procedure;

    #[ORM\Column(type: 'string', length: 100)]
    private $description;

    #[ORM\Column(type: 'integer')]
    private $nombre_procedures;

    #[ORM\Column(type: 'float')]
    private $charge_patient;

    #[ORM\Column(type: 'float')]
    private $charge_assurance;

    #[ORM\Column(type: 'float')]
    private $charge_totaux;

    #[ORM\OneToMany(mappedBy: 'procedureRendezVous', targetEntity: Patient::class, orphanRemoval: true)]
    private $patient;

    #[ORM\OneToMany(mappedBy: 'procedureRendezVous', targetEntity: Frais::class)]
    private $frais;

    #[ORM\OneToMany(mappedBy: 'procedure', targetEntity: FacturationPaiement::class)]
    private $facturationPaiements;

    

    

    public function __construct()
    {
        $this->patient = new ArrayCollection();
        $this->frais = new ArrayCollection();
        $this->facturation_paiement = new ArrayCollection();
        $this->facturationPaiements = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getCodeProcedure(): ?int
    {
        return $this->code_procedure;
    }

    public function setCodeProcedure(int $code_procedure): self
    {
        $this->code_procedure = $code_procedure;

        return $this;
    }

    public function getDate(): ?\DateTimeInterface
    {
        return $this->date;
    }

    public function setDate(\DateTimeInterface $date): self
    {
        $this->date = $date;

        return $this;
    }

    public function getTypeProcedure(): ?string
    {
        return $this->type_procedure;
    }

    public function setTypeProcedure(string $type_procedure): self
    {
        $this->type_procedure = $type_procedure;

        return $this;
    }

    public function getDescription(): ?string
    {
        return $this->description;
    }

    public function setDescription(string $description): self
    {
        $this->description = $description;

        return $this;
    }

    public function getNombreProcedures(): ?int
    {
        return $this->nombre_procedures;
    }

    public function setNombreProcedures(int $nombre_procedures): self
    {
        $this->nombre_procedures = $nombre_procedures;

        return $this;
    }

    public function getChargePatient(): ?float
    {
        return $this->charge_patient;
    }

    public function setChargePatient(float $charge_patient): self
    {
        $this->charge_patient = $charge_patient;

        return $this;
    }

    public function getChargeAssurance(): ?float
    {
        return $this->charge_assurance;
    }

    public function setChargeAssurance(float $charge_assurance): self
    {
        $this->charge_assurance = $charge_assurance;

        return $this;
    }

    public function getChargeTotaux(): ?float
    {
        return $this->charge_totaux;
    }

    public function setChargeTotaux(float $charge_totaux): self
    {
        $this->charge_totaux = $charge_totaux;

        return $this;
    }

    /**
     * @return Collection<int, Patient>
     */
    public function getPatient(): Collection
    {
        return $this->patient;
    }

    public function addPatient(Patient $patient): self
    {
        if (!$this->patient->contains($patient)) {
            $this->patient[] = $patient;
            $patient->setProcedureRendezVous($this);
        }

        return $this;
    }

    public function removePatient(Patient $patient): self
    {
        if ($this->patient->removeElement($patient)) {
            // set the owning side to null (unless already changed)
            if ($patient->getProcedureRendezVous() === $this) {
                $patient->setProcedureRendezVous(null);
            }
        }

        return $this;
    }

    /**
     * @return Collection<int, Frais>
     */
    public function getFrais(): Collection
    {
        return $this->frais;
    }

    public function addFrai(Frais $frai): self
    {
        if (!$this->frais->contains($frai)) {
            $this->frais[] = $frai;
            $frai->setProcedureRendezVous($this);
        }

        return $this;
    }

    public function removeFrai(Frais $frai): self
    {
        if ($this->frais->removeElement($frai)) {
            // set the owning side to null (unless already changed)
            if ($frai->getProcedureRendezVous() === $this) {
                $frai->setProcedureRendezVous(null);
            }
        }

        return $this;
    }

    
    public function __toString(){
    return $this->type_procedure ; // Remplacer champ par une propri�t� "string" de l'entit�
    }

    /**
     * @return Collection<int, FacturationPaiement>
     */
    public function getFacturationPaiements(): Collection
    {
        return $this->facturationPaiements;
    }

    public function addFacturationPaiement(FacturationPaiement $facturationPaiement): self
    {
        if (!$this->facturationPaiements->contains($facturationPaiement)) {
            $this->facturationPaiements[] = $facturationPaiement;
            $facturationPaiement->setProcedure($this);
        }

        return $this;
    }

    public function removeFacturationPaiement(FacturationPaiement $facturationPaiement): self
    {
        if ($this->facturationPaiements->removeElement($facturationPaiement)) {
            // set the owning side to null (unless already changed)
            if ($facturationPaiement->getProcedure() === $this) {
                $facturationPaiement->setProcedure(null);
            }
        }

        return $this;
    }

   
    

   
}
