<?php

namespace App\Entity;

use App\Repository\FactureRepository;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: FactureRepository::class)]
class Facture
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 255)]
    private $date_emission;

    #[ORM\Column(type: 'string', length: 255)]
    private $cordonees_patient;

    #[ORM\Column(type: 'float')]
    private $frais_patient;

    #[ORM\Column(type: 'float', nullable: true)]
    private $frais_assurance;

    #[ORM\Column(type: 'float', nullable: true)]
    private $frais_employe;

    #[ORM\Column(type: 'float')]
    private $frais_totaux;

    #[ORM\Column(type: 'boolean', nullable: true)]
    private $is_reduction;

    #[ORM\Column(type: 'boolean', nullable: true)]
    private $is_penalite;

    #[ORM\Column(type: 'boolean', nullable: true)]
    private $is_assurance;

    #[ORM\ManyToOne(targetEntity: Patient::class, inversedBy: 'factures')]
    #[ORM\JoinColumn(nullable: false)]
    private $patient;

    #[ORM\OneToMany(mappedBy: 'facture', targetEntity: Ajouter::class, orphanRemoval: true)]
    private $ajouters;

    public function __construct()
    {
        $this->ajouters = new ArrayCollection();
    }

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getDateEmission(): ?string
    {
        return $this->date_emission;
    }

    public function setDateEmission(\DateTimeInterface $date_emission): self
    {
        $this->date_emission = $date_emission;

        return $this;
    }

    public function getCordoneesPatient(): ?string
    {
        return $this->cordonees_patient;
    }

    public function setCordoneesPatient(string $cordonees_patient): self
    {
        $this->cordonees_patient = $cordonees_patient;

        return $this;
    }

    public function getFraisPatient(): ?float
    {
        return $this->frais_patient;
    }

    public function setFraisPatient(float $frais_patient): self
    {
        $this->frais_patient = $frais_patient;

        return $this;
    }

    public function getFraisAssurance(): ?float
    {
        return $this->frais_assurance;
    }

    public function setFraisAssurance(?float $frais_assurance): self
    {
        $this->frais_assurance = $frais_assurance;

        return $this;
    }

    public function getFraisEmploye(): ?float
    {
        return $this->frais_employe;
    }

    public function setFraisEmploye(?float $frais_employe): self
    {
        $this->frais_employe = $frais_employe;

        return $this;
    }

    public function getFraisTotaux(): ?float
    {
        return $this->frais_totaux;
    }

    public function setFraisTotaux(float $frais_totaux): self
    {
        $this->frais_totaux = $frais_totaux;

        return $this;
    }

    public function getIsReduction(): ?bool
    {
        return $this->is_reduction;
    }

    public function setIsReduction(?bool $is_reduction): self
    {
        $this->is_reduction = $is_reduction;

        return $this;
    }

    public function getIsPenalite(): ?bool
    {
        return $this->is_penalite;
    }

    public function setIsPenalite(?bool $is_penalite): self
    {
        $this->is_penalite = $is_penalite;

        return $this;
    }

    public function getIsAssurance(): ?bool
    {
        return $this->is_assurance;
    }

    public function setIsAssurance(?bool $is_assurance): self
    {
        $this->is_assurance = $is_assurance;

        return $this;
    }

    public function getPatient(): ?Patient
    {
        return $this->patient;
    }

    public function setPatient(?Patient $patient): self
    {
        $this->patient = $patient;

        return $this;
    }

    /**
     * @return Collection<int, Ajouter>
     */
    public function getAjouters(): Collection
    {
        return $this->ajouters;
    }

    public function addAjouter(Ajouter $ajouter): self
    {
        if (!$this->ajouters->contains($ajouter)) {
            $this->ajouters[] = $ajouter;
            $ajouter->setFacture($this);
        }

        return $this;
    }

    public function removeAjouter(Ajouter $ajouter): self
    {
        if ($this->ajouters->removeElement($ajouter)) {
            // set the owning side to null (unless already changed)
            if ($ajouter->getFacture() === $this) {
                $ajouter->setFacture(null);
            }
        }

        return $this;
    }
}
