<?php

namespace App\Entity;

use App\Repository\FraisRepository;
use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity(repositoryClass: FraisRepository::class)]
class Frais
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private $id;

    #[ORM\Column(type: 'string', length: 100, nullable: true)]
    private $etape;

    #[ORM\Column(type: 'integer', unique: true)]
    private $code_frais;

    #[ORM\Column(type: 'float')]
    private $frais;

    #[ORM\Column(type: 'integer', nullable: true)]
    private $penalite;

    #[ORM\ManyToOne(targetEntity: ProcedureRendezVous::class, inversedBy: 'frais')]
    #[ORM\JoinColumn(nullable: false)]
    private $procedureRendezVous;

    public function getId(): ?int
    {
        return $this->id;
    }

    public function getEtape(): ?string
    {
        return $this->etape;
    }

    public function setEtape(?string $etape): self
    {
        $this->etape = $etape;

        return $this;
    }

    public function getCodeFrais(): ?int
    {
        return $this->code_frais;
    }

    public function setCodeFrais(int $code_frais): self
    {
        $this->code_frais = $code_frais;

        return $this;
    }

    public function getFrais(): ?float
    {
        return $this->frais;
    }

    public function setFrais(float $frais): self
    {
        $this->frais = $frais;

        return $this;
    }

    public function getPenalite(): ?int
    {
        return $this->penalite;
    }

    public function setPenalite(?int $penalite): self
    {
        $this->penalite = $penalite;

        return $this;
    }

    public function getProcedureRendezVous(): ?ProcedureRendezVous
    {
        return $this->procedureRendezVous;
    }

    public function setProcedureRendezVous(?ProcedureRendezVous $procedureRendezVous): self
    {
        $this->procedureRendezVous = $procedureRendezVous;

        return $this;
    }
}
