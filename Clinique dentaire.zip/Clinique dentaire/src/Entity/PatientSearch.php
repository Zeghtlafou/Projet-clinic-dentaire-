<?php

namespace App\Entity;

use App\Repository\PatientSearchRepository;
use Doctrine\ORM\Mapping as ORM;


class PatientSearch
{
    

    
    public $name;

   

    public function getName(): ?string
    {
        return $this->name;
    }

    public function setName(?string $name): self
    {
        $this->name = $name;

        return $this;
    }
}
